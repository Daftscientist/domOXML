"""Placeholder/layout/master/theme effective-style resolution for the reverse reader.

ECMA-376 precedence chain (highest to lowest):
  slide p:spPr / p:txBody rPr|pPr
  → layout placeholder spPr / txBody lstStyle
  → master placeholder spPr / txBody lstStyle
  → master p:txStyles (titleStyle / bodyStyle / otherStyle per ph type)
  → theme font/color scheme defaults

Color-transform formulas (ECMA-376 §20.1.2.3 / §20.1.8.*)
  All transforms operate on HLS or sRGB as stated:
  - lumMod  : new_L = L * value               (HLS, in [0, 1])
  - lumOff  : new_L = L + value               (HLS, clamped to [0, 1])
  - shade   : new_ch = ch * value             (sRGB per-channel, scales toward black)
  - tint    : new_ch = ch + (1 - ch) * value  (sRGB per-channel, scales toward white)
  - alpha   : replaces alpha channel directly (value is the fraction in [0, 1])
  - satMod  : new_S = S * value               (HLS, clamped to [0, 1])
  Transforms are applied in document order (child element order).
"""

from __future__ import annotations

import copy
from dataclasses import dataclass
from xml.etree.ElementTree import Element

from domoxml.core.colour_transform import apply_color_transforms

_A = "http://schemas.openxmlformats.org/drawingml/2006/main"
_P = "http://schemas.openxmlformats.org/presentationml/2006/main"
_NS = {"a": _A, "p": _P}

# Placeholder types that resolve to each txStyles slot.
_TITLE_TYPES = frozenset({"title", "ctrTitle"})
_BODY_TYPES = frozenset({"body", "subTitle"})

# lstStyle level attribute → XPath tag name (a:lvl1pPr … a:lvl9pPr).
_LVL_TAG = {i: f"{{{_A}}}lvl{i}pPr" for i in range(1, 10)}

_PPR_CHOICE_GROUPS = (
    frozenset(f"{{{_A}}}{name}" for name in ("buClrTx", "buClr")),
    frozenset(f"{{{_A}}}{name}" for name in ("buSzTx", "buSzPct", "buSzPts")),
    frozenset(f"{{{_A}}}{name}" for name in ("buFontTx", "buFont")),
    frozenset(f"{{{_A}}}{name}" for name in ("buNone", "buAutoNum", "buChar", "buBlip")),
)
_RPR_CHOICE_GROUPS = (
    frozenset(
        f"{{{_A}}}{name}"
        for name in ("noFill", "solidFill", "gradFill", "blipFill", "pattFill", "grpFill")
    ),
    frozenset(f"{{{_A}}}{name}" for name in ("effectLst", "effectDag")),
    frozenset(f"{{{_A}}}{name}" for name in ("uLnTx", "uLn")),
    frozenset(f"{{{_A}}}{name}" for name in ("uFillTx", "uFill")),
)

# Theme font scheme: typeface values that redirect to the theme major/minor font.
_MAJOR_SENTINEL = "+mj-lt"
_MINOR_SENTINEL = "+mn-lt"


# ---------------------------------------------------------------------------
# Context carriers — pre-parsed per slide so helpers stay stateless.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PlaceholderContext:
    """Pre-looked-up XML elements for one placeholder shape's inheritance chain.

    ``None`` means a level is absent (e.g. no layout or no master placeholder
    for this idx/type combination).  ``master_tx_styles`` is the master-level
    ``p:txStyles`` element (which carries titleStyle/bodyStyle/otherStyle)."""

    ph_type: str  # the ph type attribute value; empty string if not a ph
    ph_idx: int  # the ph idx attribute; 0 if absent (title default)
    layout_ph_sppr: Element | None  # layout placeholder spPr
    layout_ph_body_pr: Element | None  # layout placeholder txBody bodyPr
    layout_ph_lstStyle: Element | None  # layout placeholder txBody lstStyle
    master_ph_sppr: Element | None  # master placeholder spPr
    master_ph_body_pr: Element | None  # master placeholder txBody bodyPr
    master_ph_lstStyle: Element | None  # master placeholder txBody lstStyle
    master_tx_styles: Element | None  # master p:txStyles


@dataclass(frozen=True)
class ThemeContext:
    """Theme-level resources for one slide."""

    major_latin: str  # a:fontScheme majorFont a:latin typeface
    minor_latin: str  # a:fontScheme minorFont a:latin typeface
    colors: dict[str, str]  # resolved hex strings keyed by scheme slot name
    default_text_style: Element | None = None  # presentation p:defaultTextStyle


# ---------------------------------------------------------------------------
# Placeholder lookup helpers
# ---------------------------------------------------------------------------


def _ph_element(sp: Element) -> Element | None:
    """Return the p:ph element inside p:nvSpPr/p:nvPr, or None."""
    return sp.find("p:nvSpPr/p:nvPr/p:ph", _NS)


def _ph_attrs(ph: Element) -> tuple[str, int]:
    """(type, idx) from a p:ph element (with ECMA defaults)."""
    return ph.get("type", "body"), int(ph.get("idx", "0"))


def _find_ph_in_tree(root: Element, ph_type: str, ph_idx: int) -> Element | None:
    """Find the best-matching placeholder sp in a layout/master XML root.

    Matching priority per ECMA-376 §19.3.1.36:
      1. Exact idx match
      2. Type match (when idx alone does not resolve)
    For title/ctrTitle on a slide, fall back to any master ph with type=title.
    """
    exact_idx: Element | None = None
    type_match: Element | None = None
    for sp in root.findall(".//p:sp", _NS):
        cand_ph = _ph_element(sp)
        if cand_ph is None:
            continue
        cand_type, cand_idx = _ph_attrs(cand_ph)
        if cand_idx == ph_idx:
            exact_idx = sp
            break
        if type_match is None and cand_type == ph_type:
            type_match = sp
    return exact_idx if exact_idx is not None else type_match


def _master_ph_type(ph_type: str) -> str:
    """Map a slide/layout ph type to the canonical master ph type for lookup.

    ctrTitle → title, subTitle → body (master has generic title/body).
    """
    if ph_type == "ctrTitle":
        return "title"
    if ph_type == "subTitle":
        return "body"
    return ph_type


def build_placeholder_context(
    slide_sp: Element,
    layout_root: Element | None,
    master_root: Element | None,
) -> PlaceholderContext | None:
    """Build a PlaceholderContext for a slide shape, or None if not a placeholder."""
    ph = _ph_element(slide_sp)
    if ph is None:
        return None
    ph_type, ph_idx = _ph_attrs(ph)

    layout_ph_sppr: Element | None = None
    layout_ph_body_pr: Element | None = None
    layout_ph_lstStyle: Element | None = None
    master_ph_sppr: Element | None = None
    master_ph_body_pr: Element | None = None
    master_ph_lstStyle: Element | None = None
    master_tx_styles: Element | None = None

    if layout_root is not None:
        layout_sp = _find_ph_in_tree(layout_root, ph_type, ph_idx)
        if layout_sp is not None:
            layout_ph_sppr = layout_sp.find("p:spPr", _NS)
            layout_body = layout_sp.find("p:txBody", _NS)
            if layout_body is not None:
                layout_ph_body_pr = layout_body.find("a:bodyPr", _NS)
                layout_ph_lstStyle = layout_body.find("a:lstStyle", _NS)

    if master_root is not None:
        master_type = _master_ph_type(ph_type)
        master_sp = _find_ph_in_tree(master_root, master_type, ph_idx)
        if master_sp is not None:
            master_ph_sppr = master_sp.find("p:spPr", _NS)
            master_body = master_sp.find("p:txBody", _NS)
            if master_body is not None:
                master_ph_body_pr = master_body.find("a:bodyPr", _NS)
                master_ph_lstStyle = master_body.find("a:lstStyle", _NS)
        master_tx_styles = master_root.find("p:txStyles", _NS)

    return PlaceholderContext(
        ph_type=ph_type,
        ph_idx=ph_idx,
        layout_ph_sppr=layout_ph_sppr,
        layout_ph_body_pr=layout_ph_body_pr,
        layout_ph_lstStyle=layout_ph_lstStyle,
        master_ph_sppr=master_ph_sppr,
        master_ph_body_pr=master_ph_body_pr,
        master_ph_lstStyle=master_ph_lstStyle,
        master_tx_styles=master_tx_styles,
    )


# ---------------------------------------------------------------------------
# Geometry (xfrm) inheritance
# ---------------------------------------------------------------------------


def inherit_xfrm(
    slide_sppr: Element | None,
    ctx: PlaceholderContext | None,
) -> Element | None:
    """Return the first a:xfrm found in the precedence chain (slide → layout → master)."""
    for sppr in _sppr_chain(slide_sppr, ctx):
        xfrm = sppr.find("a:xfrm", _NS)
        if xfrm is not None:
            return xfrm
    return None


# ---------------------------------------------------------------------------
# spPr child inheritance (fill, line, effects)
# ---------------------------------------------------------------------------


def inherit_sppr_child(
    tag: str,
    slide_sppr: Element | None,
    ctx: PlaceholderContext | None,
) -> Element | None:
    """Return the first occurrence of ``tag`` in the spPr precedence chain."""
    for sppr in _sppr_chain(slide_sppr, ctx):
        found = sppr.find(tag, _NS)
        if found is not None:
            return found
    return None


def _sppr_chain(
    slide_sppr: Element | None,
    ctx: PlaceholderContext | None,
) -> list[Element]:
    chain: list[Element] = []
    if slide_sppr is not None:
        chain.append(slide_sppr)
    if ctx is not None:
        if ctx.layout_ph_sppr is not None:
            chain.append(ctx.layout_ph_sppr)
        if ctx.master_ph_sppr is not None:
            chain.append(ctx.master_ph_sppr)
    return chain


# ---------------------------------------------------------------------------
# Text-style inheritance for paragraphs and runs
# ---------------------------------------------------------------------------


def resolve_ppr(
    slide_ppr: Element | None,
    level: int,
    ctx: PlaceholderContext | None,
) -> Element | None:
    """Merge effective ``a:pPr`` values through the full precedence chain."""
    lvl_tag = _LVL_TAG.get(max(1, min(9, level + 1)))
    if lvl_tag is None:
        return copy.deepcopy(slide_ppr) if slide_ppr is not None else None
    chain: list[Element] = [slide_ppr] if slide_ppr is not None else []
    for lst in _lstStyle_chain(ctx):
        lvl_ppr = lst.find(lvl_tag, _NS)
        if lvl_ppr is not None:
            chain.append(lvl_ppr)
    if not chain:
        return None

    result = copy.deepcopy(chain[0])

    def inherit_missing(
        target: Element,
        fallback: Element,
        choice_groups: tuple[frozenset[str], ...],
    ) -> None:
        for name, value in fallback.attrib.items():
            target.attrib.setdefault(name, value)
        for fallback_child in fallback:
            target_child = next(
                (child for child in target if child.tag == fallback_child.tag),
                None,
            )
            has_choice = any(
                fallback_child.tag in group and any(child.tag in group for child in target)
                for group in choice_groups
            )
            if target_child is None and not has_choice:
                target.append(copy.deepcopy(fallback_child))
            elif target_child is not None and target_child.tag == f"{{{_A}}}defRPr":
                inherit_missing(target_child, fallback_child, _RPR_CHOICE_GROUPS)

    for fallback in chain[1:]:
        inherit_missing(result, fallback, _PPR_CHOICE_GROUPS)
    return result


def _tx_style_for_type(tx_styles: Element, ph_type: str) -> Element | None:
    if ph_type in _TITLE_TYPES:
        return tx_styles.find("p:titleStyle", _NS)
    if ph_type in _BODY_TYPES:
        return tx_styles.find("p:bodyStyle", _NS)
    return tx_styles.find("p:otherStyle", _NS)


def _lstStyle_chain(ctx: PlaceholderContext | None) -> list[Element]:
    """Return ordered list of lstStyle Elements to search for level pPr/rPr."""
    chain: list[Element] = []
    if ctx is None:
        return chain
    if ctx.layout_ph_lstStyle is not None:
        chain.append(ctx.layout_ph_lstStyle)
    if ctx.master_ph_lstStyle is not None:
        chain.append(ctx.master_ph_lstStyle)
    if ctx.master_tx_styles is not None:
        style = _tx_style_for_type(ctx.master_tx_styles, ctx.ph_type)
        if style is not None:
            chain.append(style)
    return chain


def resolve_run_rpr(
    slide_rpr: Element | None,
    level: int,
    ctx: PlaceholderContext | None,
    *,
    own_list_style: Element | None = None,
    default_style: Element | None = None,
) -> Element | None:
    """Return the effective run properties, merging the chain nearest first.

    The chain is the shape's own ``a:lstStyle``, the layout and master placeholders and the
    master's text styles, then the presentation's default text style. A nearer link overrides a
    farther one property by property, so a layout that only sets the size still inherits the
    master's colour and font.
    """
    if slide_rpr is not None:
        return slide_rpr
    lvl_tag = _LVL_TAG.get(max(1, min(9, level + 1)))
    if lvl_tag is None:
        return None
    styles = [own_list_style, *_lstStyle_chain(ctx), default_style]
    merged: Element | None = None
    for style in styles:
        lvl_ppr = style.find(lvl_tag, _NS) if style is not None else None
        defRPr = lvl_ppr.find("a:defRPr", _NS) if lvl_ppr is not None else None
        if defRPr is None:
            continue
        if merged is None:
            merged = copy.deepcopy(defRPr)
            continue
        for name, value in defRPr.attrib.items():
            merged.attrib.setdefault(name, value)
        for farther in defRPr:
            decided = any(
                farther.tag in group and any(child.tag in group for child in merged)
                for group in _RPR_CHOICE_GROUPS
            ) or any(child.tag == farther.tag for child in merged)
            if not decided:
                merged.append(copy.deepcopy(farther))
    return merged


# ---------------------------------------------------------------------------
# Theme font scheme resolution
# ---------------------------------------------------------------------------


def resolve_typeface(typeface: str, theme: ThemeContext) -> str:
    """Resolve +mj-lt / +mn-lt theme-font sentinels to the actual family name."""
    if typeface == _MAJOR_SENTINEL:
        return theme.major_latin or "sans-serif"
    if typeface == _MINOR_SENTINEL:
        return theme.minor_latin or "sans-serif"
    return typeface or "sans-serif"


def parse_theme_fonts(theme_root: Element) -> tuple[str, str]:
    """Return (major_latin, minor_latin) from an a:theme XML root."""
    major_el = theme_root.find(".//a:fontScheme/a:majorFont/a:latin", _NS)
    minor_el = theme_root.find(".//a:fontScheme/a:minorFont/a:latin", _NS)
    major_tf = (major_el.get("typeface", "") if major_el is not None else "") or "Calibri Light"
    minor_tf = (minor_el.get("typeface", "") if minor_el is not None else "") or "Calibri"
    return major_tf, minor_tf


# ---------------------------------------------------------------------------
# Color-transform resolution
# ---------------------------------------------------------------------------


def resolve_scheme_color(
    scheme_el: Element,
    colors: dict[str, str],
) -> tuple[int, int, int, float] | None:
    """Resolve an a:schemeClr element to (r, g, b, a), applying all child transforms.

    ``colors`` is the fully-remapped theme color dict produced by ``_slide_colors``.
    Returns None if the slot cannot be resolved.
    """
    slot = scheme_el.get("val", "")
    hex_val = colors.get(slot)
    if hex_val is None or len(hex_val) != 6:
        return None
    try:
        r, g, b = int(hex_val[0:2], 16), int(hex_val[2:4], 16), int(hex_val[4:6], 16)
    except ValueError:
        return None
    r, g, b, a = apply_color_transforms(r, g, b, 1.0, scheme_el)
    return r, g, b, a
