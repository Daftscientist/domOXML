"""SVG path ``d`` attribute parser → IR path commands.

Supported subset (ECMA-376 § SVG path data):
  M/m  moveto
  L/l  lineto
  H/h  horizontal lineto
  V/v  vertical lineto
  C/c  cubic Bézier
  Q/q  quadratic Bézier
  Z/z  close path

Unsupported commands (bail to raster with warning):
  S/s  smooth cubic Bézier
  T/t  smooth quadratic Bézier
  A/a  arc

All coordinates are normalised to **absolute** values in the SVG user-space (pixels / viewBox
units), then scaled by the caller to EMU.  Relative commands are accumulated into the current
cursor; implicit command repetition is handled per the SVG spec.
"""

from __future__ import annotations

import math
import re
from typing import NamedTuple

from domoxml.core.ir.model import (
    ArcTo,
    ClosePath,
    CubicTo,
    LineTo,
    MoveTo,
    PathCommand,
    Point,
    QuadTo,
)

# ---------------------------------------------------------------------------
# Tokeniser
# ---------------------------------------------------------------------------

# Split on whitespace, commas, and sign boundaries (a sign that follows a digit/dot starts
# the next coordinate, per the SVG spec).
_TOKEN_RE = re.compile(r"[MmLlHhVvCcQqZzSsTtAa]|[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?")


def _tokenise(d: str) -> list[str]:
    return _TOKEN_RE.findall(d)


# ---------------------------------------------------------------------------
# Public result type
# ---------------------------------------------------------------------------


class ParsedPath(NamedTuple):
    """Result from :func:`parse_svg_path`."""

    commands: list[PathCommand]
    """Normalised absolute-coordinate path commands."""
    bail_reason: str | None
    """Non-``None`` when an unsupported command was encountered; commands up to
    that point are included but the path is incomplete."""


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

_UNSUPPORTED = frozenset("SsTt")
_COORD_CMDS = frozenset("MmLlHhVvCcQqZzAa")


def _pop(tokens: list[str], index: int) -> tuple[float, int]:
    return float(tokens[index]), index + 1


def _has_coordinates(tokens: list[str], index: int, count: int) -> bool:
    """Return whether the next ``count`` tokens are numeric coordinates."""
    if index + count > len(tokens):
        return False
    return all(
        token.upper() not in _COORD_CMDS | _UNSUPPORTED for token in tokens[index : index + count]
    )


def _truncated(commands: list[PathCommand], cmd: str, arity: int) -> ParsedPath:
    return ParsedPath(commands, f"truncated SVG command '{cmd}': expected {arity} coordinates")


def parse_svg_path(d: str) -> ParsedPath:
    """Parse an SVG path ``d`` string into normalised absolute IR commands.

    Returns a :class:`ParsedPath` — check ``bail_reason`` before using ``commands``.
    Relative commands are accumulated against the current pen position (cx, cy).
    The implicit repetition rule: after the initial command, repeated coordinate pairs
    reuse the same command letter (``M`` repeats as ``L``, ``m`` as ``l``).
    """
    tokens = _tokenise(d.strip())
    commands: list[PathCommand] = []
    cx: float = 0.0  # current pen position
    cy: float = 0.0
    subpath_x, subpath_y = 0.0, 0.0  # start of current subpath (for Z)

    i = 0
    cmd = ""
    while i < len(tokens):
        tok = tokens[i]
        if tok.upper() in _COORD_CMDS or tok.upper() in _UNSUPPORTED:
            cmd = tok
            i += 1
        # If no command yet and we have a coordinate: error
        if cmd == "":
            break

        if cmd in _UNSUPPORTED:
            return ParsedPath(commands, f"unsupported SVG command '{cmd}' — bailing to raster")

        # --- Z / z ---
        if cmd in ("Z", "z"):
            commands.append(ClosePath())
            cx, cy = subpath_x, subpath_y
            # Z/z has no arguments; next token must be a new command
            cmd = ""
            continue

        # --- M / m ---
        if cmd == "M":
            if not _has_coordinates(tokens, i, 2):
                return _truncated(commands, cmd, 2)
            x, i = _pop(tokens, i)
            y, i = _pop(tokens, i)
            cx, cy = x, y
            subpath_x, subpath_y = cx, cy
            commands.append(MoveTo(to=Point(x=round(cx), y=round(cy))))
            cmd = "L"  # implicit repeat → lineto
            continue

        if cmd == "m":
            if not _has_coordinates(tokens, i, 2):
                return _truncated(commands, cmd, 2)
            dx, i = _pop(tokens, i)
            dy, i = _pop(tokens, i)
            cx += dx
            cy += dy
            subpath_x, subpath_y = cx, cy
            commands.append(MoveTo(to=Point(x=round(cx), y=round(cy))))
            cmd = "l"  # implicit repeat → relative lineto
            continue

        # --- L / l ---
        if cmd == "L":
            if not _has_coordinates(tokens, i, 2):
                return _truncated(commands, cmd, 2)
            x, i = _pop(tokens, i)
            y, i = _pop(tokens, i)
            cx, cy = x, y
            commands.append(LineTo(to=Point(x=round(cx), y=round(cy))))
            continue

        if cmd == "l":
            if not _has_coordinates(tokens, i, 2):
                return _truncated(commands, cmd, 2)
            dx, i = _pop(tokens, i)
            dy, i = _pop(tokens, i)
            cx += dx
            cy += dy
            commands.append(LineTo(to=Point(x=round(cx), y=round(cy))))
            continue

        # --- H / h ---
        if cmd == "H":
            if not _has_coordinates(tokens, i, 1):
                return _truncated(commands, cmd, 1)
            x, i = _pop(tokens, i)
            cx = x
            commands.append(LineTo(to=Point(x=round(cx), y=round(cy))))
            continue

        if cmd == "h":
            if not _has_coordinates(tokens, i, 1):
                return _truncated(commands, cmd, 1)
            dx, i = _pop(tokens, i)
            cx += dx
            commands.append(LineTo(to=Point(x=round(cx), y=round(cy))))
            continue

        # --- V / v ---
        if cmd == "V":
            if not _has_coordinates(tokens, i, 1):
                return _truncated(commands, cmd, 1)
            y, i = _pop(tokens, i)
            cy = y
            commands.append(LineTo(to=Point(x=round(cx), y=round(cy))))
            continue

        if cmd == "v":
            if not _has_coordinates(tokens, i, 1):
                return _truncated(commands, cmd, 1)
            dy, i = _pop(tokens, i)
            cy += dy
            commands.append(LineTo(to=Point(x=round(cx), y=round(cy))))
            continue

        # --- C / c  (cubic Bézier: x1 y1 x2 y2 x y) ---
        if cmd == "C":
            if not _has_coordinates(tokens, i, 6):
                return _truncated(commands, cmd, 6)
            x1, i = _pop(tokens, i)
            y1, i = _pop(tokens, i)
            x2, i = _pop(tokens, i)
            y2, i = _pop(tokens, i)
            x, i = _pop(tokens, i)
            y, i = _pop(tokens, i)
            commands.append(
                CubicTo(
                    c1=Point(x=round(x1), y=round(y1)),
                    c2=Point(x=round(x2), y=round(y2)),
                    to=Point(x=round(x), y=round(y)),
                )
            )
            cx, cy = x, y
            continue

        if cmd == "c":
            if not _has_coordinates(tokens, i, 6):
                return _truncated(commands, cmd, 6)
            dx1, i = _pop(tokens, i)
            dy1, i = _pop(tokens, i)
            dx2, i = _pop(tokens, i)
            dy2, i = _pop(tokens, i)
            dx, i = _pop(tokens, i)
            dy, i = _pop(tokens, i)
            commands.append(
                CubicTo(
                    c1=Point(x=round(cx + dx1), y=round(cy + dy1)),
                    c2=Point(x=round(cx + dx2), y=round(cy + dy2)),
                    to=Point(x=round(cx + dx), y=round(cy + dy)),
                )
            )
            cx += dx
            cy += dy
            continue

        # --- Q / q  (quadratic Bézier: x1 y1 x y) ---
        if cmd == "Q":
            if not _has_coordinates(tokens, i, 4):
                return _truncated(commands, cmd, 4)
            x1, i = _pop(tokens, i)
            y1, i = _pop(tokens, i)
            x, i = _pop(tokens, i)
            y, i = _pop(tokens, i)
            commands.append(
                QuadTo(
                    c1=Point(x=round(x1), y=round(y1)),
                    to=Point(x=round(x), y=round(y)),
                )
            )
            cx, cy = x, y
            continue

        if cmd == "q":
            if not _has_coordinates(tokens, i, 4):
                return _truncated(commands, cmd, 4)
            dx1, i = _pop(tokens, i)
            dy1, i = _pop(tokens, i)
            dx, i = _pop(tokens, i)
            dy, i = _pop(tokens, i)
            commands.append(
                QuadTo(
                    c1=Point(x=round(cx + dx1), y=round(cy + dy1)),
                    to=Point(x=round(cx + dx), y=round(cy + dy)),
                )
            )
            cx += dx
            cy += dy
            continue

        # --- A / a  (elliptical arc: rx ry rotation large sweep x y), as cubics ---
        if cmd in ("A", "a"):
            if not _has_coordinates(tokens, i, 7):
                return _truncated(commands, cmd, 7)
            rx, i = _pop(tokens, i)
            ry, i = _pop(tokens, i)
            rotation, i = _pop(tokens, i)
            large, i = _pop(tokens, i)
            sweep, i = _pop(tokens, i)
            raw_x, i = _pop(tokens, i)
            raw_y, i = _pop(tokens, i)
            end_x: float = raw_x + (cx if cmd == "a" else 0.0)
            end_y: float = raw_y + (cy if cmd == "a" else 0.0)
            for points in arc_to_cubics(
                (cx, cy), rx, ry, rotation, large != 0, sweep != 0, (end_x, end_y)
            ):
                if len(points) == 1:
                    commands.append(LineTo(to=Point(x=round(points[0][0]), y=round(points[0][1]))))
                else:
                    c1, c2, end = points
                    commands.append(
                        CubicTo(
                            c1=Point(x=round(c1[0]), y=round(c1[1])),
                            c2=Point(x=round(c2[0]), y=round(c2[1])),
                            to=Point(x=round(end[0]), y=round(end[1])),
                        )
                    )
            cx, cy = float(end_x), float(end_y)
            continue

        # Unknown command: break
        break

    return ParsedPath(commands, None)


# ---------------------------------------------------------------------------
# Arcs
# ---------------------------------------------------------------------------


def arc_to_cubics(
    p0: tuple[float, float],
    rx: float,
    ry: float,
    rotation: float,
    large: bool,
    sweep: bool,
    p1: tuple[float, float],
) -> list[list[tuple[float, float]]]:
    """An SVG elliptical arc as cubic segments ``[c1, c2, end]`` (the spec's endpoint-to-centre
    conversion). A zero radius is a straight line, returned as ``[end]``."""
    if p0 == p1:
        return []
    rx, ry = abs(rx), abs(ry)
    if rx == 0 or ry == 0:
        return [[p1]]
    phi = math.radians(rotation % 360)
    cp, sp = math.cos(phi), math.sin(phi)
    dx, dy = (p0[0] - p1[0]) / 2, (p0[1] - p1[1]) / 2
    x1, y1 = cp * dx + sp * dy, -sp * dx + cp * dy
    lam = x1 * x1 / (rx * rx) + y1 * y1 / (ry * ry)
    if lam > 1:
        rx, ry = rx * math.sqrt(lam), ry * math.sqrt(lam)
    numerator = rx * rx * ry * ry - rx * rx * y1 * y1 - ry * ry * x1 * x1
    denominator = rx * rx * y1 * y1 + ry * ry * x1 * x1
    factor = math.sqrt(max(0.0, numerator / denominator)) * (-1 if large == sweep else 1)
    cx1, cy1 = factor * rx * y1 / ry, -factor * ry * x1 / rx
    cx = cp * cx1 - sp * cy1 + (p0[0] + p1[0]) / 2
    cy = sp * cx1 + cp * cy1 + (p0[1] + p1[1]) / 2

    def angle(ux: float, uy: float, vx: float, vy: float) -> float:
        value = math.atan2(ux * vy - uy * vx, ux * vx + uy * vy)
        return value

    theta = angle(1, 0, (x1 - cx1) / rx, (y1 - cy1) / ry)
    delta = angle((x1 - cx1) / rx, (y1 - cy1) / ry, (-x1 - cx1) / rx, (-y1 - cy1) / ry)
    if not sweep and delta > 0:
        delta -= 2 * math.pi
    elif sweep and delta < 0:
        delta += 2 * math.pi
    pieces = max(1, math.ceil(abs(delta) / (math.pi / 2) - 1e-9))
    step = delta / pieces
    k = 4 / 3 * math.tan(step / 4)
    segments: list[list[tuple[float, float]]] = []

    def at(t: float) -> tuple[float, float]:
        return (
            cx + rx * math.cos(t) * cp - ry * math.sin(t) * sp,
            cy + rx * math.cos(t) * sp + ry * math.sin(t) * cp,
        )

    def derivative(t: float) -> tuple[float, float]:
        return (
            -rx * math.sin(t) * cp - ry * math.cos(t) * sp,
            -rx * math.sin(t) * sp + ry * math.cos(t) * cp,
        )

    for piece in range(pieces):
        t0, t1 = theta + piece * step, theta + (piece + 1) * step
        a, b, da, db = at(t0), at(t1), derivative(t0), derivative(t1)
        segments.append(
            [(a[0] + k * da[0], a[1] + k * da[1]), (b[0] - k * db[0], b[1] - k * db[1]), b]
        )
    return segments


# ---------------------------------------------------------------------------
# Scale helpers
# ---------------------------------------------------------------------------


def scale_path_to_emu(
    commands: list[PathCommand],
    *,
    vb_w: float,
    vb_h: float,
    box_emu_w: int,
    box_emu_h: int,
    align: tuple[float, float] | None = None,
) -> list[PathCommand]:
    """Scale path commands from SVG viewBox units to EMU coordinates.

    ``vb_w``/``vb_h`` are the viewBox dimensions; ``box_emu_w``/``box_emu_h`` are the
    target bounding box in EMUs.  ClosePath has no coordinates and passes through unchanged.

    By default the viewBox is stretched to the box. With ``align`` (the fractions
    ``(x, y)`` of the free space placed before the content: 0, 0.5 or 1) it keeps its aspect
    ratio and sits inside the box, which is what an SVG does with ``preserveAspectRatio`` ``meet``.
    """
    if vb_w <= 0 or vb_h <= 0:
        return commands

    sx = box_emu_w / vb_w
    sy = box_emu_h / vb_h
    offset_x = offset_y = 0.0
    if align is not None:
        sx = sy = min(sx, sy)
        offset_x = (box_emu_w - vb_w * sx) * align[0]
        offset_y = (box_emu_h - vb_h * sy) * align[1]

    def _pt(p: Point) -> Point:
        return Point(x=round(p.x * sx + offset_x), y=round(p.y * sy + offset_y))

    result: list[PathCommand] = []
    for cmd in commands:
        if isinstance(cmd, MoveTo):
            result.append(MoveTo(to=_pt(cmd.to)))
        elif isinstance(cmd, LineTo):
            result.append(LineTo(to=_pt(cmd.to)))
        elif isinstance(cmd, CubicTo):
            result.append(CubicTo(c1=_pt(cmd.c1), c2=_pt(cmd.c2), to=_pt(cmd.to)))
        elif isinstance(cmd, QuadTo):
            result.append(QuadTo(c1=_pt(cmd.c1), to=_pt(cmd.to)))
        elif isinstance(cmd, ArcTo):
            result.append(
                ArcTo(
                    width_radius=round(cmd.width_radius * sx),
                    height_radius=round(cmd.height_radius * sy),
                    start_angle=cmd.start_angle,
                    sweep_angle=cmd.sweep_angle,
                )
            )
        else:
            result.append(cmd)  # ClosePath
    return result


# ---------------------------------------------------------------------------
# Reverse: IR path commands → SVG d string
# ---------------------------------------------------------------------------


def commands_to_svg_d(commands: tuple[PathCommand, ...]) -> str:
    """Serialize IR path commands back to an SVG ``d`` attribute string."""
    parts: list[str] = []
    current_x = 0.0
    current_y = 0.0
    subpath_x = 0.0
    subpath_y = 0.0
    for cmd in commands:
        if isinstance(cmd, MoveTo):
            parts.append(f"M {cmd.to.x} {cmd.to.y}")
            current_x, current_y = cmd.to.x, cmd.to.y
            subpath_x, subpath_y = current_x, current_y
        elif isinstance(cmd, LineTo):
            parts.append(f"L {cmd.to.x} {cmd.to.y}")
            current_x, current_y = cmd.to.x, cmd.to.y
        elif isinstance(cmd, CubicTo):
            parts.append(f"C {cmd.c1.x} {cmd.c1.y} {cmd.c2.x} {cmd.c2.y} {cmd.to.x} {cmd.to.y}")
            current_x, current_y = cmd.to.x, cmd.to.y
        elif isinstance(cmd, QuadTo):
            parts.append(f"Q {cmd.c1.x} {cmd.c1.y} {cmd.to.x} {cmd.to.y}")
            current_x, current_y = cmd.to.x, cmd.to.y
        elif isinstance(cmd, ArcTo):
            start = math.radians(cmd.start_angle / 60_000)
            center_x = current_x - cmd.width_radius * math.cos(start)
            center_y = current_y - cmd.height_radius * math.sin(start)
            sweep = int(cmd.sweep_angle >= 0)
            remaining = cmd.sweep_angle
            angle = cmd.start_angle
            while remaining:
                segment = max(-10_800_000, min(10_800_000, remaining))
                angle += segment
                end = math.radians(angle / 60_000)
                current_x = center_x + cmd.width_radius * math.cos(end)
                current_y = center_y + cmd.height_radius * math.sin(end)
                parts.append(
                    "A "
                    f"{cmd.width_radius} {cmd.height_radius} 0 0 {sweep} "
                    f"{round(current_x)} {round(current_y)}"
                )
                remaining -= segment
        else:
            parts.append("Z")
            current_x, current_y = subpath_x, subpath_y
    return " ".join(parts)
