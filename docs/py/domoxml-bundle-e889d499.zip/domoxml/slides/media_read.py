"""PresentationML video and audio node parsing."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import PurePosixPath
from typing import Literal
from xml.etree import ElementTree
from xml.etree.ElementTree import Element

from domoxml.core.ir.model import Box, MediaNode, PictureFill
from domoxml.core.media import is_glb
from domoxml.core.opc import OpcPackage

_A = "http://schemas.openxmlformats.org/drawingml/2006/main"
_P = "http://schemas.openxmlformats.org/presentationml/2006/main"
_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
_NS = {"a": _A, "p": _P}
_EMBED = f"{{{_R}}}embed"
_LINK = f"{{{_R}}}link"

type PosterParser = Callable[[Element], PictureFill | None]


def _int_attr(element: Element, name: str, default: int = 0) -> int:
    try:
        return int(element.get(name, str(default)))
    except ValueError:
        return default


def read_media(
    element: Element,
    package: OpcPackage,
    slide_part: str,
    poster_for: PosterParser,
) -> MediaNode | None:
    """Read a video/audio picture, including embedded or external media relationships."""
    non_visual = element.find("p:nvPicPr/p:nvPr", _NS)
    if non_visual is None:
        return None
    # PowerPoint writes the link in the DrawingML namespace (``a:videoFile``); the PresentationML
    # spelling is accepted too for files that used it.
    media = non_visual.find("a:videoFile", _NS)
    if media is None:
        media = non_visual.find("p:videoFile", _NS)
    kind: Literal["video", "audio"] = "video"
    if media is None:
        media = non_visual.find("a:audioFile", _NS)
        if media is None:
            media = non_visual.find("p:audioFile", _NS)
        kind = "audio"
    if media is None:
        return None

    properties = element.find("p:spPr", _NS)
    transform = properties.find("a:xfrm", _NS) if properties is not None else None
    offset = transform.find("a:off", _NS) if transform is not None else None
    extent = transform.find("a:ext", _NS) if transform is not None else None
    if properties is None or offset is None or extent is None:
        return None
    box = Box(
        x=_int_attr(offset, "x"),
        y=_int_attr(offset, "y"),
        width=_int_attr(extent, "cx"),
        height=_int_attr(extent, "cy"),
    )

    relationship_id = media.get(_LINK) or media.get(_EMBED)
    media_data: bytes | None = None
    media_url: str | None = None
    media_ext = "mp4"
    if relationship_id is not None:
        for relationship in package.relationships(slide_part):
            if relationship.id != relationship_id:
                continue
            if relationship.target_mode != "Internal":
                media_url = relationship.target
                suffix = PurePosixPath(relationship.target.split("?", 1)[0]).suffix
            else:
                try:
                    media_part = package.resolve(slide_part, relationship)
                    media_data = package.read(media_part)
                    suffix = PurePosixPath(media_part).suffix
                except (KeyError, ValueError):
                    suffix = ""
            media_ext = suffix.lower().lstrip(".") or media_ext
            break

    blip_fill = element.find("p:blipFill", _NS)
    poster = poster_for(blip_fill) if blip_fill is not None else None
    play_settings = non_visual.find("p:videoPr" if kind == "video" else "p:audioPr", _NS)
    play_xml = (
        ElementTree.tostring(play_settings, encoding="unicode")
        if play_settings is not None
        else None
    )
    return MediaNode(
        box=box,
        kind=kind,
        media_data=media_data,
        media_url=media_url,
        media_ext=media_ext,
        poster_fill=poster,
        play_settings_xml=play_xml,
    )


_WEB_NS = "http://schemas.microsoft.com/office/webextensions/webextension/2010/11"
_WEB_NAMES = {"we": _WEB_NS, "p": _P, "a": _A}
# The Web Viewer add-in's store id: what makes PowerPoint show a page in a frame.
WEB_VIEWER_ID = "WA104295837"


def read_web_viewer(element: Element, package: OpcPackage, slide_part: str) -> MediaNode | None:
    """A Web Viewer ``p:graphicFrame``: the page it shows and the snapshot PowerPoint draws."""
    reference = element.find("a:graphic/a:graphicData/we:webextensionref", _WEB_NAMES)
    transform = element.find("p:xfrm", _WEB_NAMES)
    offset = transform.find("a:off", _WEB_NAMES) if transform is not None else None
    extent = transform.find("a:ext", _WEB_NAMES) if transform is not None else None
    if reference is None or offset is None or extent is None:
        return None
    try:
        extension_part = package.related_part(slide_part, reference.get(_EMBED_ID, ""))
        extension = ElementTree.fromstring(package.read(extension_part).decode("utf-8"))
    except (KeyError, ValueError, ElementTree.ParseError, UnicodeDecodeError):
        return None
    # Only the Web Viewer is a page frame; another add-in keeps its identity as preserved source.
    reference_id = extension.find("we:reference", _WEB_NAMES)
    if reference_id is None or reference_id.get("id") != WEB_VIEWER_ID:
        return None
    url = None
    for prop in extension.iterfind("we:properties/we:property", _WEB_NAMES):
        if prop.get("name") == "url":
            url = (prop.get("value") or "").strip().strip('"') or None
    if url is None:
        return None
    poster: PictureFill | None = None
    snapshot = extension.find("we:snapshot", _WEB_NAMES)
    if snapshot is not None:
        try:
            image_part = package.related_part(extension_part, snapshot.get(_EMBED, ""))
            suffix = PurePosixPath(image_part).suffix.lower().lstrip(".")
            ext = "jpeg" if suffix == "jpg" else suffix
            if ext == "png" or ext == "jpeg" or ext == "gif":
                poster = PictureFill(data=package.read(image_part), ext=ext)
        except (KeyError, ValueError):
            poster = None
    return MediaNode(
        box=Box(
            x=_int_attr(offset, "x"),
            y=_int_attr(offset, "y"),
            width=_int_attr(extent, "cx"),
            height=_int_attr(extent, "cy"),
        ),
        kind="web",
        media_url=url,
        poster_fill=poster,
    )


_EMBED_ID = f"{{{_R}}}id"


_MODEL_NS = "http://schemas.microsoft.com/office/drawing/2017/model3d"
_MC = "http://schemas.openxmlformats.org/markup-compatibility/2006"
_MODEL_NAMES = {"am3d": _MODEL_NS, "a": _A, "p": _P, "mc": _MC}
# What decides how the model is seen: kept verbatim so a re-save shows it the same way.
_VIEW_PARTS = frozenset({"camera", "trans", "ambientLight", "ptLight", "dirLight", "spotLight"})


def read_model_frame(
    alternate: Element, package: OpcPackage, slide_part: str
) -> tuple[MediaNode, Element] | None:
    """A 3-D model ``mc:AlternateContent``: the GLB, its poster and its camera and lights.

    Also returns the ``p:graphicFrame`` that owns the shape identity. A model whose part is
    missing or is not binary glTF is not modelled here and stays preserved source.
    """
    frame = alternate.find("mc:Choice/p:graphicFrame", _MODEL_NAMES)
    model = (
        frame.find("a:graphic/a:graphicData/am3d:model3d", _MODEL_NAMES)
        if frame is not None
        else None
    )
    transform = frame.find("p:xfrm", _MODEL_NAMES) if frame is not None else None
    offset = transform.find("a:off", _MODEL_NAMES) if transform is not None else None
    extent = transform.find("a:ext", _MODEL_NAMES) if transform is not None else None
    if frame is None or model is None or offset is None or extent is None:
        return None
    try:
        data = package.read(package.related_part(slide_part, model.get(_EMBED, "")))
    except (KeyError, ValueError):
        return None
    if not is_glb(data):
        return None
    poster: PictureFill | None = None
    # The render saved with the model, else the picture older readers draw in its place.
    for blip in (
        model.find("am3d:raster/am3d:blip", _MODEL_NAMES),
        alternate.find("mc:Fallback/p:pic/p:blipFill/a:blip", _MODEL_NAMES),
    ):
        if blip is None or poster is not None:
            continue
        try:
            image_part = package.related_part(slide_part, blip.get(_EMBED, ""))
            suffix = PurePosixPath(image_part).suffix.lower().lstrip(".")
            ext = "jpeg" if suffix == "jpg" else suffix
            if ext == "png" or ext == "jpeg" or ext == "gif":
                poster = PictureFill(data=package.read(image_part), ext=ext)
        except (KeyError, ValueError):
            continue
    ElementTree.register_namespace("am3d", _MODEL_NS)
    ElementTree.register_namespace("a", _A)
    view = "".join(
        ElementTree.tostring(child, encoding="unicode")
        for child in model
        if child.tag.rpartition("}")[2] in _VIEW_PARTS
    )
    return (
        MediaNode(
            box=Box(
                x=_int_attr(offset, "x"),
                y=_int_attr(offset, "y"),
                width=_int_attr(extent, "cx"),
                height=_int_attr(extent, "cy"),
            ),
            kind="model",
            media_data=data,
            media_ext="glb",
            poster_fill=poster,
            play_settings_xml=view or None,
        ),
        frame,
    )
