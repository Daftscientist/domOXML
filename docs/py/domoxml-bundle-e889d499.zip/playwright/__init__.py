"""Stub for the web bundle: Playwright is never used here."""
