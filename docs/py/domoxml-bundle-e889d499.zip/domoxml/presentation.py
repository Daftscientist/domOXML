"""The ``Presentation`` — author a deck from per-slide HTML, render to editable OOXML."""

from __future__ import annotations

import asyncio
from collections.abc import Sequence
from pathlib import Path
from typing import Literal, Self

from domoxml.core.fonts import resolve_faces
from domoxml.core.html import serialize_canvas
from domoxml.core.ir import extract_slide
from domoxml.core.ir.model import SlideTransition
from domoxml.core.render import BrowserSession, RenderedSlide, compose_page
from domoxml.core.render.takumi_backend import TakumiRenderedSlide, TakumiSession, extract_takumi
from domoxml.core.units import pixels
from domoxml.slides import build_pptx, read_pptx_result
from domoxml.types import (
    ConversionWarning,
    CoverageItem,
    CoverageReport,
    HtmlPresentation,
    OutputFormat,
    RenderResult,
    SizeSpec,
    Slide,
    SlideSize,
    Theme,
)


class Presentation:
    """A deck of HTML-authored slides that renders to an editable ``.pptx`` (+ PNG).

    Build it up, optionally edit ``slides`` in place, then ``render`` it::

        deck = Presentation(size=SlideSize.WIDE_16_9)
        deck.add(Slide(html="<h1>Hello</h1>"))
        result = deck.render({OutputFormat.PPTX, OutputFormat.PNG})

    ``PPTX``, ``PNG``, and deterministic per-slide ``HTML`` are supported.
    """

    def __init__(
        self,
        *,
        theme: Theme | None = None,
        size: SizeSpec = SlideSize.WIDE_16_9,
        css: str | None = None,
        render_engine: Literal["chromium", "takumi"] = "chromium",
        transitions: Sequence[SlideTransition | None] | None = None,
        rendered_slides: Sequence[RenderedSlide] | None = None,
    ) -> None:
        if render_engine not in ("chromium", "takumi"):
            raise ValueError(f"unsupported render_engine: {render_engine}")
        self.render_engine = render_engine
        # Pre-rendered slides (host capture): when supplied, rendering is
        # already done — a host environment (e.g. the page a Pyodide build
        # runs in) captured each slide's layout itself, and _render returns
        # these instead of opening a session. Extraction, font resolution
        # and emission are unchanged.
        self._rendered_slides: tuple[RenderedSlide, ...] | None = (
            tuple(rendered_slides) if rendered_slides is not None else None
        )
        # Per-slide transitions, aligned with ``slides`` order; ``None`` entries
        # (or a shorter sequence) leave that slide without a transition. Applied
        # to the extracted IR before the deck is built, so they round-trip
        # through PPTX exactly like transitions read from an existing deck.
        self.transitions: tuple[SlideTransition | None, ...] = tuple(transitions or ())
        self.theme: Theme = theme or Theme()
        self.size: SizeSpec = size
        self.css: str | None = css
        self.slides: list[Slide] = []

    def add(self, slide: Slide) -> Self:
        """Append a slide and return ``self`` (chainable)."""
        self.slides.append(slide)
        return self

    @classmethod
    def from_pptx(
        cls,
        source: bytes | Path,
        *,
        fallback_pngs: Sequence[bytes] | None = None,
    ) -> HtmlPresentation:
        """Read a ``.pptx`` into deterministic per-slide HTML/CSS.

        Pass one authoritative render per slide in ``fallback_pngs`` to keep unsupported
        source visuals visible through explicit element-layer or rasterized fallbacks.
        """
        return pptx_to_html(source, fallback_pngs=fallback_pngs)

    def render(
        self, formats: set[OutputFormat], *, indices: set[int] | None = None
    ) -> RenderResult:
        """Render the deck. ``indices`` limits work to specific slides (live preview)."""
        return asyncio.run(self.arender(formats, indices=indices))

    async def arender(
        self,
        formats: set[OutputFormat],
        *,
        indices: set[int] | None = None,
    ) -> RenderResult:
        """Async variant of :meth:`render`."""
        needs_render = bool(formats & {OutputFormat.PNG, OutputFormat.PPTX, OutputFormat.HTML})
        rendered = await self._render(indices) if needs_render else []

        pngs = tuple(slide.png for slide in rendered) if OutputFormat.PNG in formats else ()

        pptx: bytes | None = None
        html = None
        slide_irs = []
        coverage: list[CoverageItem] = []
        warnings: list[ConversionWarning] = []
        needs_extract = bool(formats & {OutputFormat.PPTX, OutputFormat.HTML})
        if needs_extract and rendered:
            extracts = [
                extract_takumi(slide)
                if isinstance(slide, TakumiRenderedSlide)
                else extract_slide(slide)
                for slide in rendered
            ]
            for extracted in extracts:
                coverage.extend(extracted.coverage)
                warnings.extend(extracted.warnings)
            slide_irs = [extracted.slide for extracted in extracts]
            if self.transitions:
                # ``indices`` renders a subset; transitions stay aligned with the
                # full deck order, so map through the rendered positions.
                positions = (
                    sorted(indices) if indices is not None else list(range(len(self.slides)))
                )
                slide_irs = [
                    ir.model_copy(update={"transition": self.transitions[pos]})
                    if pos < len(self.transitions) and self.transitions[pos] is not None
                    else ir
                    for pos, ir in zip(positions, slide_irs, strict=True)
                ]

            if OutputFormat.HTML in formats:
                html = serialize_canvas(slide_irs)

        if OutputFormat.PPTX in formats and rendered:
            captured_fonts: dict[str, bytes] = {}
            for slide in rendered:
                if isinstance(slide, RenderedSlide):
                    captured_fonts.update(slide.resources)
            faces, font_warnings = resolve_faces(slide_irs, captured_fonts=captured_fonts)
            warnings.extend(font_warnings)
            pptx = build_pptx(slide_irs, faces=faces)

        return RenderResult(
            pptx=pptx,
            pngs=pngs,
            html=html,
            coverage=CoverageReport(items=tuple(coverage)),
            warnings=tuple(warnings),
        )

    def save_pptx(self, path: Path) -> None:
        """Render and write the editable ``.pptx`` to ``path``."""
        result = self.render({OutputFormat.PPTX})
        if result.pptx is None:  # pragma: no cover - render always sets it when requested
            raise RuntimeError("PPTX render produced no output")
        path.write_bytes(result.pptx)

    def save_png(self, directory: Path) -> None:
        """Render and write one PNG per slide into ``directory`` (``slide-NN.png``)."""
        result = self.render({OutputFormat.PNG})
        directory.mkdir(parents=True, exist_ok=True)
        for index, png in enumerate(result.pngs, start=1):
            (directory / f"slide-{index:02d}.png").write_bytes(png)

    async def _render(self, indices: set[int] | None) -> list[RenderedSlide | TakumiRenderedSlide]:
        if indices is None:
            chosen = self.slides
        else:
            invalid = sorted(i for i in indices if i not in range(len(self.slides)))
            if invalid:
                raise IndexError(f"slide indices out of range: {invalid}")
            chosen = [self.slides[i] for i in sorted(indices)]

        if not chosen:  # nothing to render — don't spin up a browser
            return []

        if self._rendered_slides is not None:
            if len(self._rendered_slides) != len(self.slides):
                raise ValueError(
                    f"rendered_slides has {len(self._rendered_slides)} slides "
                    f"for a deck of {len(self.slides)}"
                )
            if indices is None:
                return list(self._rendered_slides)
            return [self._rendered_slides[i] for i in sorted(indices)]

        rendered: list[RenderedSlide | TakumiRenderedSlide] = []
        session_backend = BrowserSession() if self.render_engine == "chromium" else TakumiSession()
        async with session_backend as session:
            for slide in chosen:
                width, height = pixels(slide.size or self.size)
                page = compose_page(
                    slide.html, css=self.css, theme=self.theme, width_px=width, height_px=height
                )
                rendered.append(await session.render(page, width=width, height=height))
        return rendered


def pptx_to_html(
    source: bytes | Path, *, fallback_pngs: Sequence[bytes] | None = None
) -> HtmlPresentation:
    """Read PPTX bytes or a path into deterministic per-slide HTML/CSS."""
    pptx = source.read_bytes() if isinstance(source, Path) else source
    result = read_pptx_result(pptx, fallback_pngs=fallback_pngs)
    return serialize_canvas(
        list(result.slides),
        warnings=result.warnings,
        preserved=result.preserved,
        embedded_fonts=result.embedded_fonts,
        coverage=result.coverage,
    )
