"""Import-time stub for ``playwright.async_api`` (web bundle only).

``domoxml.core.render.browser`` imports these names at module level. The web
build renders with Takumi instead of Chromium, so the names exist purely to
satisfy the import; constructing or calling any of them raises.
"""

from __future__ import annotations


class _Unavailable:
    def __init__(self, *args, **kwargs):
        raise RuntimeError("Playwright is not available in the web build; Takumi is the render backend")


Browser = _Unavailable
Page = _Unavailable
Playwright = _Unavailable
Route = _Unavailable


def async_playwright():
    raise RuntimeError("Playwright is not available in the web build; Takumi is the render backend")
